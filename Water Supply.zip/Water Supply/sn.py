from flask import *
app = Flask(__name__)
@app.route("/login")
def login():
	return render_template("snlogin.html")
@app.route("/reg")
def reg():
	return render_template("snreg.html")
@app.route("/user_access")
def user_access():
	return render_template("sn_user_access.html")
@app.route("/admin_access")
def admin_access():
	return render_template("sn_admin_access.html")
@app.route("/feedback")
def feedback():
	return render_template("snfeedback.html")
@app.route("/homepage")
def homepage():
	return render_template("sn_dpws.html")
	
if __name__ == '__main__':
	app.run(debug=True)
